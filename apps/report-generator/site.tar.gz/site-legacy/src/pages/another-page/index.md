---
title: Another Page
layout: minimal
---
## Welcome to another page

_Markdown_ page using a different layout.
